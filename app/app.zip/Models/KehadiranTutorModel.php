<?php

namespace App\Models;

use CodeIgniter\Model;

class KehadiranTutorModel extends Model
{
    protected $table = 'kehadiran_tutor';
    protected $primaryKey = 'id_kehadiran';
    protected $returnType = 'object';
    protected $allowedFields = ['id_kehadiran', 'id_tutor', 'id_workshop', 'inclass',];

    public function _get()
    {
        return $this->findAll();
    }

    public function _findById($id)
    {
        return $this->find($id);
    }

    public function _insert($data)
    {
        $this->insert($data);
    }

    public function _update($id, $data)
    {
        $this->update($id, $data);
    }

    public function _delete($id)
    {
        $this->delete($id);
    }

    public function _getTutorByWorkshop($id_workshop)
    {
        $result = $this->select('tutor.*')
            ->where('id_workshop', $id_workshop)
            ->join('tutor', 'tutor.id_tutor = kehadiran_tutor.id_tutor')
            ->get()
            ->getResult();
        return $result;
    }

    public function _getWorkshopByTutor($id_tutor)
    {
        $result = $this->select('workshop.*, jadwal.*, venue.*')
            ->where('id_tutor', $id_tutor)
            ->join('workshop', 'workshop.id_workshop = kehadiran_tutor.id_workshop')
            ->join('jadwal', 'jadwal.id_jadwal = workshop.id_jadwal')
            ->join('venue', 'venue.id_venue = workshop.id_venue')
            ->get()
            ->getResult();
        return $result;
    }

    public function _getInclass($idTutor, $idWorkshop)
    {
        return $this->select('kehadiran_tutor.inclass')
            ->where("id_tutor = '" . $idTutor . "' && id_workshop = '" . $idWorkshop . "'")
            ->get()
            ->getResult();
    }

    public function _findId($idTutor, $idWorkshop)
    {
        return $this->select('kehadiran_tutor.id_kehadiran')
            ->where("id_tutor = '" . $idTutor . "' && id_workshop = '" . $idWorkshop . "'")
            ->get()
            ->getResult();
    }

    public function _findBy($idTutor, $idWorkshop)
    {
        return $this->where("id_tutor = '" . $idTutor . "' && id_workshop = '" . $idWorkshop . "'")
            ->get()
            ->getResult();
    }

    public function _deleteByWorkshop($id_workshop)
    {
        $this->where('id_workshop', $id_workshop)->delete();
    }

    public function _getProposal()
    {
        $result = $this->where('inclass', 2)
            ->join('tutor', 'tutor.id_tutor = kehadiran_tutor.id_tutor')
            ->join('workshop', 'workshop.id_workshop = kehadiran_tutor.id_workshop')
            ->join('jadwal', 'jadwal.id_jadwal = workshop.id_jadwal')
            ->get()
            ->getResult();

        return $result;
    }
}

<?php namespace App\Models;

use CodeIgniter\Model;

class PicModel extends Model{
    protected $table = 'pic';
    protected $primaryKey = 'id_pic';
    protected $returnType = 'object';
    protected $allowedFields = ['id_pic', 'nama_pic', 'jenis_kelamin', 'email', 'nomor_hp', 'alamat', 'id_kecamatan', 'asal', 'id_kategori', 'id_sub_kategori', 'username'];

    public function _get(){
        return $this->findAll();
    }

    public function _findById($id){
        return $this->find($id);
    }

    public function _insert($data){
        $this->insert($data);
    }

    public function _update($id, $data){
        $this->update($id, $data);
    }

    public function _delete($id){
        $this->delete($id);
    }

    public function _getOnlyId(){
        return $this->select('id_peserta')
        ->get()
        ->getResult();
    }

    public function _getWithKategori(){
        $result = $this->select('*')
        ->join('kategori', 'kategori.id_kategori = pic.id_kategori')
        ->join('sub_kategori', 'sub_kategori.id_sub_kategori = pic.id_sub_kategori', 'left')
        ->get()
        ->getResult();
        return $result;
    }
    public function _getAllInfoById($idPic){
        $result = $this->select('*')
        ->where('id_pic', $idPic)
        ->join('kecamatan', 'kecamatan.id_kecamatan = pic.id_kecamatan')
        ->join('kabupaten', 'kabupaten.id_kabupaten = kecamatan.id_kabupaten')
        ->join('provinsi', 'provinsi.id_provinsi = kabupaten.id_provinsi')
        ->join('kategori', 'kategori.id_kategori = pic.id_kategori')
        ->join('sub_kategori', 'sub_kategori.id_sub_kategori = pic.id_sub_kategori')
        ->get()
        ->getResult();
        return $result;
    }

    public function _getByKategori($id_kategori){
        $result = $this->where('peserta.id_kategori', $id_kategori)
        ->join('kategori' , 'kategori.id_kategori = peserta.id_kategori')
        ->get()
        ->getResult();
        return $result;
    }

    public function _findByUsername($username){
        $result = $this->where('username', $username)
        ->join('kategori', 'kategori.id_kategori = pic.id_kategori')
        ->join('sub_kategori', 'sub_kategori.id_sub_kategori = pic.id_sub_kategori', 'left')
        ->get()
        ->getResult();

        return $result;
    }
}

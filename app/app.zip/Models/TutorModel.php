<?php namespace App\Models;

use CodeIgniter\Model;

class TutorModel extends Model{
    protected $table = 'tutor';
    protected $primaryKey = 'id_tutor';
    protected $returnType = 'object';
    protected $allowedFields = ['id_tutor', 'nama_tutor', 'jenis_kelamin', 'email', 'nomor_hp', 'alamat', 'asal', 'id_kecamatan', 'prestasi', 'username'];

    public function _get(){
        return $this->findAll();
    }

    public function _findById($id){
        return $this->find($id);
    }

    public function _insert($data){
        $this->insert($data);
    }

    public function _update($id, $data){
        $this->update($id, $data);
    }

    public function _delete($id){
        $this->delete($id);
    }

    public function _findByUsername($username){
        return $this->where('username', $username)
        ->get()
        ->getResult();
    }

    public function _getAllInfo(){
        $result = $this->join('kehadiran_tutor', 'kehadiran_tutor.id_tutor = tutor.id_tutor')
        ->join('workshop','workshop.id_workshop = kehadiran_tutor.id_workshop')
        ->get()
        ->getResult();

        return $result;
    }

    public function _getAllInfoById($id_tutor){
        $result = $this->where('id_tutor', $id_tutor)
        ->join('kecamatan', 'kecamatan.id_kecamatan = tutor.id_kecamatan')
        ->join('kabupaten', 'kabupaten.id_kabupaten = kecamatan.id_kabupaten')
        ->join('provinsi', 'provinsi.id_provinsi = kabupaten.id_provinsi')
        ->get()
        ->getResult();

        return $result;
    }

}

?>
<?php

namespace App\Controllers;

use App\Models\KabupatenModel;
use App\Models\KategoriModel;
use App\Models\KecamatanModel;
use App\Models\ProvinsiModel;
use App\Models\SubKategoriModel;
use App\Models\TutorModel;
use App\Models\UserModel;

class Tutor extends BaseController
{

	// MAIN FUNCTION
	// ===================================================================================

	// INDEX ==============================
	public function Index()
	{
		$tutorModel = new TutorModel;

		$alert = $this->session->getFlashdata('alert');

		$tutorData  = $tutorModel->_get();
		$userData = $this->session->userData;
		$data = [
			'tutor' => $tutorData,
			'userData' => $userData,
			'alert' => $alert,
		];

		echo view('/Tutor/Level99/Index', $data);
	}

	// VIEW ==============================
	public function View()
	{
		$tutorModel = new TutorModel;

		$idTutor = $this->request->uri->getSegment('3');

		$alert = $this->session->getFlashdata('alert');

		$tutorData  = $tutorModel->_getAllInfoById($idTutor)[0];
		$userData = $this->session->userData;
		$data = [
			'tutorData' => $tutorData,
			'userData' => $userData,
			'alert' => $alert,
		];

		echo view('/Tutor/Level99/View', $data);
	}

	// VALIDATION ==============================

	public function ValidateUsername()
	{
		if ($this->request->getVar('action') == 'validate') {
			$userModel = new UserModel;
			$username = $this->request->getVar('username');
			if ($userModel->_findById($username) != null) {
				return json_encode('fail');
			} else {
				return json_encode('success');
			}
		}
	}

	// NEW FORM ==============================

	public function newForm()
	{
		$provinsiModel = new ProvinsiModel;

		$userData = $this->session->userData;

		$data = [
			'provinsi' => $provinsiModel->_get(),
			'userData' => $userData,
		];

		return view('/Tutor/Level99/Insert', $data);
	}


	// SAVE ==============================
	public function Save()
	{
		$userModel = new UserModel;
		$tutorModel = new TutorModel;

		if ($this->request->getMethod() === 'post') {
			$idTutor = 'tut_' . rand(26451645, 99999999);
			$username = $this->request->getPost('username');
			$password = $this->request->getPost('password');
			$namaTutor = $this->request->getPost('nama_tutor');
			$jenisKelamin = $this->request->getPost('jenis_kelamin');
			$email = $this->request->getPost('email');
			$nomorHp = $this->request->getPost('nomor_hp');
			$alamat = $this->request->getPost('alamat');
			$asal = $this->request->getPost('asal');
			$kecamatan = $this->request->getPost('kecamatan');
			$hash = md5(uniqid(rand(), true));
			$prestasi = $this->request->getPost('prestasi');

			$userData = [
				'username' => $username,
				'password' => md5($password),
				'id_level' => 2,
				'hash' => $hash,
				'active' => 1,
			];

			$tutorData = [
				'id_tutor' => $idTutor,
				'nama_tutor' => $namaTutor,
				'jenis_kelamin' => $jenisKelamin,
				'email' => $email,
				'nomor_hp' => $nomorHp,
				'alamat' => $alamat,
				'id_kecamatan' => $kecamatan,
				'asal' => $asal,
				'username' => $username,
				'prestasi' => $prestasi,
			];

			// Insertion to Database ==========================
			$userModel->_Insert($userData);
			$tutorModel->_Insert($tutorData);

			$this->session->setFlashdata("alert", "<!-- javascript -->
			<script>
				$(document).ready(
					Swal.fire({
						title: 'Berhasil!',
						text: 'Berhasil menambah instruktur',
						icon: 'success',
						confirmButtonText: 'Ok'
					})
				)
			</script>");
			return redirect()->to('/Tutor');
		}
	}


	// SECONDARY FUNCTION
	// ===================================================================================

	// get kabupaten untuk update di dropdown registrasi
	public function getKabupaten()
	{
		$KabupatenModel = new KabupatenModel;
		if ($this->request->getVar('action') == 'getKabupaten') {
			$idProvinsi = $this->request->getVar('idProvinsi');
			$kabupaten = $KabupatenModel->_findByProvinsi($idProvinsi);
			$output = array(
				'kabupaten' => $kabupaten,
			);

			return json_encode($output);
		}
	}

	// get kecamatan untuk update di dropdown registrasi
	public function getKecamatan()
	{
		$kecamatanModel = new KecamatanModel;
		if ($this->request->getVar('action') == 'getKecamatan') {
			$idKabupaten = $this->request->getVar('idKabupaten');
			$kecamatan = $kecamatanModel->_findByKabupaten($idKabupaten);
			$output = array(
				'kecamatan' => $kecamatan,
			);

			return json_encode($output);
		}
	}
}

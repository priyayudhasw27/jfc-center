<?php

namespace App\Controllers;


class Kategori extends BaseController
{

	// MAIN FUNCTION
	// ===================================================================================

	// INDEX ==============================
	public function index()
	{
	}

	// VERIFICATION UNDONE ================
	public function Undone(){
		echo view('Verification/Undone');
	}

}
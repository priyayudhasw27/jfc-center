<?php

namespace App\Controllers;

use App\Models\KabupatenModel;
use App\Models\KategoriModel;
use App\Models\KecamatanModel;
use App\Models\PicModel;
use App\Models\ProvinsiModel;
use App\Models\SubKategoriModel;
use App\Models\TutorModel;
use App\Models\UserModel;

class Pic extends BaseController
{

	// MAIN FUNCTION
	// ===================================================================================

	// INDEX ==============================
	public function Index()
	{
		$picModel = new PicModel;

		$alert = $this->session->getFlashdata('alert');

		$picData = $picModel->_getWithKategori();
		$userData = $this->session->userData;

		$data = [
			'pic' => $picData,
			'userData' => $userData,
			'alert' => $alert,
		];

		echo view('/Pic/Level99/Index', $data);
	}

	// VIEW ==============================
	public function View()
	{
		$picModel = new PicModel;

		$idPic = $this->request->uri->getSegment('3');

		$picData  = $picModel->_getAllInfoById($idPic)[0];
		$userData = $this->session->userData;
		$data = [
			'picData' => $picData,
			'userData' => $userData,
		];

		echo view('/Pic/Level99/View', $data);
	}

	// VALIDATION ==============================

	public function ValidateUsername()
	{
		if ($this->request->getVar('action') == 'validate') {
			$userModel = new UserModel;
			$username = $this->request->getVar('username');
			if ($userModel->_findById($username) != null) {
				return json_encode('fail');
			} else {
				return json_encode('success');
			}
		}
	}

	// NEW FORM ==============================

	public function newForm()
	{
		$provinsiModel = new ProvinsiModel;
		$kategoriModel = new KategoriModel;
		$subKategoriModel = new SubKategoriModel;

		$userData = $this->session->userData;

		$data = [
			'kategori' => $kategoriModel->_get(),
			'subKategori' => $subKategoriModel->_get(),
			'provinsi' => $provinsiModel->_get(),
			'userData' => $userData,
		];

		return view('/Pic/Level99/Insert', $data);
	}


	// SAVE ==============================
	public function Save()
	{
		$userModel = new UserModel;
		$picModel = new PicModel;

		if ($this->request->getMethod() === 'post') {
			$idPic = 'pic_' . rand(01234, 9999);
			$username = $this->request->getPost('username');
			$password = $this->request->getPost('password');
			$namaPic = $this->request->getPost('nama_pic');
			$jenisKelamin = $this->request->getPost('jenis_kelamin');
			$email = $this->request->getPost('email');
			$nomorHp = $this->request->getPost('nomor_hp');
			$alamat = $this->request->getPost('alamat');
			$asal = $this->request->getPost('asal');
			$kecamatan = $this->request->getPost('kecamatan');
			$hash = md5(uniqid(rand(), true));
			$idKategori = $this->request->getPost('id_kategori');

			if($this->request->getPost('id_sub_kategori') == ''){
				$idSubKategori = NULL;
			}else{
				$idSubKategori = $this->request->getPost('id_sub_kategori');
			}
			

			$userData = [
				'username' => $username,
				'password' => md5($password),
				'id_level' => 3,
				'hash' => $hash,
				'active' => 1,
			];

			$tutorData = [
				'id_pic' => $idPic,
				'nama_pic' => $namaPic,
				'jenis_kelamin' => $jenisKelamin,
				'email' => $email,
				'nomor_hp' => $nomorHp,
				'alamat' => $alamat,
				'id_kecamatan' => $kecamatan,
				'asal' => $asal,
				'username' => $username,
				'id_kategori' => $idKategori,
				'id_sub_kategori' => $idSubKategori,
			];

			// print_r($idSubKategori);

			// Insertion to Database ==========================
			$userModel->_Insert($userData);
			$picModel->_Insert($tutorData);

			$this->session->setFlashdata("alert", "<!-- javascript -->
			<script>
				$(document).ready(
					Swal.fire({
						title: 'Berhasil!',
						text: 'Berhasil menambah Leader',
						icon: 'success',
						confirmButtonText: 'Ok'
					})
				)
			</script>");
			return redirect()->to('/Pic');
		}
	}


	// SECONDARY FUNCTION
	// ===================================================================================

	// get kabupaten untuk update di dropdown registrasi
	public function getKabupaten()
	{
		$KabupatenModel = new KabupatenModel;
		if ($this->request->getVar('action') == 'getKabupaten') {
			$idProvinsi = $this->request->getVar('idProvinsi');
			$kabupaten = $KabupatenModel->_findByProvinsi($idProvinsi);
			$output = array(
				'kabupaten' => $kabupaten,
			);

			return json_encode($output);
		}
	}

	// get kecamatan untuk update di dropdown registrasi
	public function getKecamatan()
	{
		$kecamatanModel = new KecamatanModel;
		if ($this->request->getVar('action') == 'getKecamatan') {
			$idKabupaten = $this->request->getVar('idKabupaten');
			$kecamatan = $kecamatanModel->_findByKabupaten($idKabupaten);
			$output = array(
				'kecamatan' => $kecamatan,
			);

			return json_encode($output);
		}
	}
}

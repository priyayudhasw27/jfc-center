<?php

namespace App\Controllers;

use App\Models\KehadiranPesertaModel;
use App\Models\KehadiranTutorModel;
use App\Models\PesertaModel;
use App\Models\TutorModel;

class AbsensiPeserta extends BaseController
{

	// MAIN FUNCTION
	// ===================================================================================

	// INDEX ==============================
	public function index()
	{
	}

	// SCANNER ==============================
	public function Scanner()
	{
		$kehadiranTutorModel = new KehadiranTutorModel;
		$tutorModel = new TutorModel;

		// get user data
		$userData = $this->session->userData;

		// get id tutor
		$idTutor = $tutorModel->_findByUsername($userData['username'])[0]->id_tutor;

		// get id workshop
		$idWorkshop = $this->request->uri->getSegment('3');

		// get kehadiran tutor data
		$kehadiranTutorData = $kehadiranTutorModel->_findBy($idTutor, $idWorkshop)[0];

		// get inclass
		$inclass = $kehadiranTutorData->inclass;

		$data = [
			'idTutor' => $idTutor,
			'idWorkshop' => $idWorkshop,
			'kehadiranTutorData' => $kehadiranTutorData,
			'userData' => $userData,
		];

		if ($inclass == 0) {
			// load view awal sebelum klik mulai workshop
			echo view('/AbsensiPeserta/ProposalView', $data);
		} else if ($inclass == 2) {
			// load view waiting approval
			echo view('/AbsensiPeserta/WaitingApprovalView', $data);
		} else if ($inclass == 1) {
			// Tutor bisa melakukan absensi
			return view('/AbsensiPeserta/ScannerView', $data);
		}
	}


	public function ApprovalTutor()
	{
		if ($this->request->getMethod() == 'post') {
			// PROPOSAL BUKA WORKSHOP =============================
			if ($this->request->getVar('action') == 'propose') {
				$kehadiranTutorModel = new KehadiranTutorModel;
				$idKehadiran = $this->request->getVar('id_kehadiran');

				$data = [
					'inclass' => 2,
				];

				$kehadiranTutorModel->_update($idKehadiran, $data);
				$output = array(
					'result' => 'success'
				);
				return json_encode($output);
			};
			// APPROVAL DARI ADMIN =============================
			if ($this->request->getVar('action') == 'approve') {
				$kehadiranTutorModel = new KehadiranTutorModel;
				$idKehadiran = $this->request->getVar('id_kehadiran');

				$data = [
					'inclass' => 1,
				];

				$kehadiranTutorModel->_update($idKehadiran, $data);
				$output = array(
					'result' => 'success'
				);
				return json_encode($output);
			}
		};
	}

	// ENROLL ==============================
	public function Enroll()
	{
		if ($this->request->getMethod() == 'post') {

			// Enroll peserta, ubah status jadi inclass
			if ($this->request->getVar('action') == "enroll") {
				$kehadiranPesertaModel = new KehadiranPesertaModel;
				$pesertaModel = new PesertaModel;

				// get id workshop
				$idWorkshop = $this->request->getVar('id_workshop');

				// get id peserta
				$idPeserta = $this->request->getVar('id_peserta');

				// get data peserta
				$pesertaData = $pesertaModel->_findById($idPeserta);

				// get id kehadiran
				$idKehadiran = $kehadiranPesertaModel->_findId($idPeserta, $idWorkshop)[0]->id_kehadiran;

				// ubah status inclass
				$kehadiranPesertaData = [
					'inclass' => 1,
				];
				$kehadiranPesertaModel->_update($idKehadiran, $kehadiranPesertaData);

				$output = array(
					'result' => $pesertaData,
				);

				return json_encode($output);
			}
		}
	}
}

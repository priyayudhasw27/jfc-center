<?php

namespace App\Controllers;

use App\Models\KehadiranPesertaModel;
use App\Models\JadwalModel;
use App\Models\KehadiranTutorModel;
use App\Models\PesertaModel;
use App\Models\TutorModel;
use App\Models\VenueModel;
use App\Models\WorkshopModel;

class Workshop extends BaseController
{

	// INDEX ==============================

	public function Index()
	{
		$userData = $this->session->userData;
		$workshopModel = new WorkshopModel;

		$alert = $this->session->getFlashdata('alert');

		// cek level untuk redirect page
		if ($userData['id_level'] == 0) {

			// page untuk peserta
			$workshop = $workshopModel->_getIncomingAllInfo();
			$data = [
				'userData' => $this->session->userData,
				'workshop' => $workshop,
				'alert' => $alert,
			];
			return view('/Workshop/Level0/Index', $data);
		} else if ($userData['id_level'] == 1) {

			// page untuk operator
			
			$kehadiranPesertaModel = new KehadiranPesertaModel;

			// get all info workshop
			$workshop = $workshopModel->_getAllInfo();

			// get total peserta hadir dan tidak hadir
			foreach ($workshop as $x){
				$pesertaHadir[$x->id_workshop] = $kehadiranPesertaModel->_countHadirByWorkshop($x->id_workshop);
				$pesertaTidakHadir[$x->id_workshop] = $kehadiranPesertaModel->_countTidakHadirByWorkshop($x->id_workshop);
			}

			$data = [
				'userData' => $this->session->userData,
				'workshop' => $workshop,
				'pesertaHadir' => $pesertaHadir,
				'pesertaTidakHadir' => $pesertaTidakHadir,
				'alert' => $alert,
			];
			
			return view('/Workshop/Level1/Index', $data);
		} else if ($userData['id_level'] == 2) {

			// page untuk tutor

			$kehadiranPesertaModel = new KehadiranPesertaModel;

			$kehadiranTutorModel = new KehadiranTutorModel;
			$tutorModel = new TutorModel;
			$idTutor = $tutorModel->_findByUsername($this->session->userData['username'])[0];
			$workshop = $kehadiranTutorModel->_getWorkshopByTutor($idTutor->id_tutor);

			// get total peserta hadir dan tidak hadir
			foreach ($workshop as $x){
				$pesertaHadir[$x->id_workshop] = $kehadiranPesertaModel->_countHadirByWorkshop($x->id_workshop);
				$pesertaTidakHadir[$x->id_workshop] = $kehadiranPesertaModel->_countTidakHadirByWorkshop($x->id_workshop);
			}
			$data = [
				'userData' => $this->session->userData,
				'workshop' => $workshop,
				'pesertaHadir' => $pesertaHadir,
				'pesertaTidakHadir' => $pesertaTidakHadir,
				'alert' => $alert,
			];
			// print_r($idTutor);
			return view('/Workshop/Level2/Index', $data);
		} else if ($userData['id_level'] == 99) {

			// page untuk operator
			$kehadiranPesertaModel = new KehadiranPesertaModel;

			$workshop = $workshopModel->_getAllInfo();

			// get total peserta hadir dan tidak hadir
			foreach ($workshop as $x){
				$pesertaHadir[$x->id_workshop] = $kehadiranPesertaModel->_countHadirByWorkshop($x->id_workshop);
				$pesertaTidakHadir[$x->id_workshop] = $kehadiranPesertaModel->_countTidakHadirByWorkshop($x->id_workshop);
			}

			$data = [
				'userData' => $this->session->userData,
				'workshop' => $workshop,
				'pesertaHadir' => $pesertaHadir,
				'pesertaTidakHadir' => $pesertaTidakHadir,
				'alert' => $alert,
			];
			return view('/Workshop/Level99/Index', $data);
		}
	}

	// VIEW ==============================

	public function View()
	{
		$userData = $this->session->userData;
		$workshopModel = new WorkshopModel;
		$kehadiranTutorModel = new KehadiranTutorModel;
		$kehadiranPesertaModel = new KehadiranPesertaModel;

		$id_workshop = $this->request->uri->getSegment('3');

		// get data workshop, jadwal, venue
		$workshop = $workshopModel->_getAllInfoById($id_workshop);

		// get data peserta
		$peserta = $kehadiranPesertaModel->_getPeserta($id_workshop);

		// get data pengampu
		$tutorPengampu = $kehadiranTutorModel->_getTutorByWorkshop($id_workshop);
		$data = [
			'userData' => $this->session->userData,
			'workshop' => $workshop[0],
			'tutor' => $tutorPengampu,
			'peserta' => $peserta,
		];

		// cek level untuk redirect page
		if ($userData['id_level'] == 0) {

			// page untuk peserta
			return view('/Workshop/Level0/View', $data);
		} else if ($userData['id_level'] == 1) {

			// page untuk operator			
			return view('/Workshop/Level1/View', $data);
		} else if ($userData['id_level'] == 2) {

			// page untuk tutor
			return view('/Workshop/Level2/View', $data);
		} else if ($userData['id_level'] == 99) {

			// page untuk tutor
			return view('/Workshop/Level99/View', $data);
		}
	}

	// =============== CRUD FORM ======================

	// NEW FORM ==============================

	public function newForm()
	{
		$tutorModel = new TutorModel;
		$venueModel = new VenueModel;

		$userData = $this->session->userData;

		$data = [
			'tutorData' => $tutorModel->_get(),
			'venueData' => $venueModel->_get(),
			'userData' => $userData,
		];
		
		if($userData['id_level'] == 1){
			return view('/Workshop/Level1/Insert', $data);
		}else if($userData['id_level'] == 99){
			return view('/Workshop/Level99/Insert', $data);
		}
	}

	// UPDATE FORM ==============================

	public function UpdateForm()
	{
		$tutorModel = new TutorModel;
		$venueModel = new VenueModel;
		$workshopModel = new WorkshopModel;
		$kehadiranTutorModel = new KehadiranTutorModel;

		$idWorkshop = $this->request->uri->getSegment('3');
		$workshopData = $workshopModel->_getAllInfoById($idWorkshop)[0];
		// get tutor tutor pengampu
		$tutorPengampuData = $kehadiranTutorModel->_getTutorByWorkshop($idWorkshop);

		$userData = $this->session->userData;

		$data = [
			'tutorData' => $tutorModel->_get(),
			'venueData' => $venueModel->_get(),
			'userData' => $userData,
			'workshop' => $workshopData,
			'tutorPengampu' => $tutorPengampuData,
		];

		if($userData['id_level'] == 1){
			return view('/Workshop/Level1/Update', $data);
		}else if($userData['id_level'] == 99){
			return view('/Workshop/Level99/Update', $data);
		}
	}

	// ================ CRUD METHOD =================

	// INSERT ==============================

	public function Insert()
	{
		if ($this->request->getMethod() == 'post') {

			$jadwalModel = new JadwalModel;
			$workshopModel = new WorkshopModel;
			$pesertaModel = new PesertaModel;
			$kehadiranTutorModel = new KehadiranTutorModel;
			$kehadiranPesertamodel = new KehadiranPesertaModel;

			$namaWorkshop = $this->request->getPost('nama_workshop');
			$materi = $this->request->getPost('materi');
			$tanggal = $this->request->getPost('tanggal');
			$waktuMulai = $this->request->getPost('waktu_mulai');
			$waktuSelesai = $this->request->getPost('waktu_selesai');
			$dresscode = $this->request->getPost('dresscode');
			$idVenue = $this->request->getPost('id_venue');
			$idTutor = $this->request->getPost('id_tutor');
			$idJadwal = 'j' . rand(0312, 9999);
			$idWorkshop = 'ws' . rand(0123, 9999);

			// INSERT JADWAL
			$jadwalData = [
				'id_jadwal' => $idJadwal,
				'waktu_mulai' => $waktuMulai,
				'waktu_selesai' => $waktuSelesai,
				'tanggal' => $tanggal,
			];
			$jadwalModel->_Insert($jadwalData);

			// INSERT WORKSHOP
			$workshopData = [
				'id_workshop' => $idWorkshop,
				'nama_workshop' => $namaWorkshop,
				'materi' => $materi,
				'id_jadwal' => $idJadwal,
				'id_venue' => $idVenue,
				'dresscode' => $dresscode,
			];
			$workshopModel->_Insert($workshopData);

			// INSERT KEHADIRAN TUTOR
			foreach ($idTutor as $x) {
				$kehadiranTutorData = [
					'id_kehadiran' => 'kt_' . rand(0123, 9999),
					'id_tutor' => $x,
					'id_workshop' => $idWorkshop,
					'inclass' => 0,
				];
				$kehadiranTutorModel->_Insert($kehadiranTutorData);
			}


			$this->session->setFlashdata("alert", "<!-- javascript -->
			<script>
				$(document).ready(
					Swal.fire({
						title: 'Berhasil!',
						text: 'Workshop berhasil ditambahkan',
						icon: 'success',
						confirmButtonText: 'Ok'
					})
				)
			</script>");
			return redirect()->to('/Workshop');
		}
	}

	// UPDATE ==============================

	public function update()
	{
		$userData = $this->session->userData;
		$workshopModel = new WorkshopModel;
		$kehadiranTutorModel = new KehadiranTutorModel;
		$venueModel = new VenueModel;

		$id_workshop = $this->request->uri->getSegment('3');

		// page untuk operator
		// get data workshop, jadwal, venue
		$workshop = $workshopModel->_getAllInfoById($id_workshop);
		// get data pengampu
		$tutorPengampu = $kehadiranTutorModel->_getTutor($id_workshop);
		$data = [
			'userData' => $userData,
			'workshop' => $workshop[0],
			'tutorPengampu' => $tutorPengampu,
			'venueData' => $venueModel->_get(),
		];
		return view('/Workshop/Level1/update', $data);
	}

	// DELETE ==============================

	public function delete()
	{
		$workshopModel = new WorkshopModel;
		$jadwalModel = new jadwalModel;
		$kehadiranTutorModel = new KehadiranTutorModel;
		$kehadiranPesertaModel = new KehadiranPesertaModel;

		$idWorkshop = $this->request->uri->getSegment('3');
		$idJadwal = $workshopModel->_findById($idWorkshop)->id_jadwal;

		// Delete dari tabel workshop ===========================
		$workshopModel->_delete($idWorkshop);

		// Delete dari tabel jadwal ===========================
		$jadwalModel->_delete($idJadwal);

		// Delete dari tabel Kehadiran tutor ===========================
		$kehadiranTutorModel->_deleteByWorkshop($idWorkshop);

		// Delete dari tabel kehadiran peserta ===========================
		$kehadiranPesertaModel->_deleteByWorkshop($idWorkshop);

		$this->session->setFlashdata("alert", "<!-- javascript -->
			<script>
				$(document).ready(
					Swal.fire({
						title: 'Berhasil!',
						text: 'Workshop berhasil dihapus',
						icon: 'success',
						confirmButtonText: 'Ok'
					})
				)
			</script>");

		return redirect()->to('/Workshop');
	}
}
